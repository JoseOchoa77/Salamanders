<?php

/* ------------------------------------------------------------------
This is comment
------------------------------------------------------------------ */

public function getFood($food) {
    
}

public function getFood($food) {
    jdjdjaj
}